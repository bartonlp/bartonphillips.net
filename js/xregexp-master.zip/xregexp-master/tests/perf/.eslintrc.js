module.exports = {
    "globals": {
        "Benchmark": true,
    }
}
