module.exports = {
    "rules": {
        "global-require": 0,
        "no-global-assign": 0,
        "no-native-reassign": 0,
    }
}
